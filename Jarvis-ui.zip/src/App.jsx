import React, { useState } from 'react'

function App() {
  const [message, setMessage] = useState('')
  const [response, setResponse] = useState('')

  const sendCommand = async () => {
    try {
      const res = await fetch('https://jarvis-backend-s8n7.onrender.com', {
        method: 'GET'
      })
      const text = await res.text()
      setResponse(text)
    } catch (error) {
      setResponse('Error: ' + error.message)
    }
  }

  return (
    <div style={{ fontFamily: 'sans-serif', textAlign: 'center', marginTop: '50px' }}>
      <h1>🚀 Jarvis UI</h1>
      <p>Test if backend is working</p>
      <button onClick={sendCommand}>Ping Backend</button>
      <p style={{ marginTop: '20px' }}>{response}</p>
    </div>
  )
}

export default App